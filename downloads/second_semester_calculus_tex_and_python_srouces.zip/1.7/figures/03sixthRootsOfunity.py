from math import *
from grapher import *

setViewBox(-2, -2, 2, 2)
openOutputFile("03sixthRootsOfUnity", 240)

OR=[0,0]

line([-2,0], [-1,0])
arrow([1,0], [1.99,0], len=7, wid=2, overshoot=0)
arrow([0, -2], [0, 1.99],len=7, wid=2, overshoot=0)

phi = pi/3
roots=[]
for k in range(6): roots.append([cos(k*phi), sin(k*phi)])

linewidth(0.5)
setdash("[3 3] 0")
arc(OR, 1, [0, 360])
for z in roots:
    line(OR, z)

setdash("[] 0")
#linewidth(0.5)
for z in roots:
    roundPoint(z, 0.03)

annotate(roots[0], [3,4], makeboxl("$1$"))
annotate(roots[1], [2,2], makeboxl(r"$\tfrac12 + \tfrac i2\sqrt3$"))
annotate(roots[2], [-2,2], makeboxr(r"$-\tfrac12 + \tfrac i2\sqrt3$"))
annotate(roots[3], [-4,3], makeboxr(r"$-1$"))
annotate(roots[4], [-2,-9], makeboxr(r"$-\tfrac12 - \tfrac i2\sqrt3$"))
annotate(roots[5], [2, -9], makeboxl(r"$\tfrac12 - \tfrac i2\sqrt3$"))

closeOutputFile()
