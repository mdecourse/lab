from math import *
from grapher import *

setViewBox(-4, -1, 4, 4)
openOutputFile("03multbyi", 180)

OR=[0,0]
a=12/4.0
b= 5/4.0
c=13/4.0
theta = atan(b/a)*180/pi

polygonF([OR, [a, 0], [a, b]],fillcolor=[200,200,200])
polygonF([OR, [0, a], [-b,a]],fillcolor=[200,200,200])

axes()

arrow(OR, [a, b], len=7, wid=2, overshoot=0)
arrow(OR, [-b, a], len=7, wid=2, overshoot=0)


arc([0,0], 2, [theta, theta+90])
p = (2/c)*(-b)
q = (2/c)* a
arrowhead([p+a,q+b-0.2], [p,q], len=7, wid=2, overshoot=0)

annotate([a,b], [2, 2], makeboxl("$z=a+bi$"))
annotate([-b,a], [-2, 2], makeboxr("$iz=-b+ai$"))

closeOutputFile()
