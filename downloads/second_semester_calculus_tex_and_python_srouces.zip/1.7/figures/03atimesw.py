from math import *
from grapher import *

setViewBox(-5, -3, 7, 4)
openOutputFile("03atimesw", 180)

OR=[0,0]

a=2.0
b=1.0
axes([7,7])

line([-3*a, -3*b], [4*a, 4*b])
for k in [-2, -1, 1, 2, 3]:
    roundPoint([k*a, k*b], 0.08)

annotate([-2*a, -2*b], [-2, 2], makeboxr("$-2z$"))
annotate([-a, -b], [-2, 2], makeboxr("$-z$"))
annotate([a, b], [2, -8], makeboxl("$z$"))
annotate([2*a, 2*b], [2, -8], makeboxl("$2z$"))
annotate([3*a, 3*b], [2, -8], makeboxl("$3z$"))

closeOutputFile()
