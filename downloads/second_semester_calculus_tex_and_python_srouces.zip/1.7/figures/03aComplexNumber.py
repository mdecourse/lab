#!/usr/bin/python
# A complex number
from math import *
from grapher import *


setViewBox(-1, -1, 5, 4)
openOutputFile("03aComplexNumber", 210)

axes([7,7])
linewidth(0.5)
origin = [0,0]
Z = [4.0, 2.0]
theta = atan(Z[1]/Z[0])

arrow(origin, Z, len=7, wid=2, overshoot=0)
arcendpoint = [2*cos(theta), 2*sin(theta)]
a =[arcendpoint[0]+1.8, arcendpoint[1]-4]
arrowhead(a, arcendpoint, len=7, wid=2, overshoot=0)
setdash("[3 3] 0")
line([Z[0], 0], Z)
line([0, Z[1]], Z)
arc(origin, 2.0, [0.0, 180/pi * theta])
setdash("[] 0")
roundPoint([Z[0], 0], 0.03)
roundPoint([0, Z[1]], 0.03)

annotate(Z, [2, 2], makeboxl("$z=a+bi$"))
annotate([Z[0],0], [-2, -10], makeboxl("$a = \Re(z)$"))
annotate([0, Z[1]], [-2, 0], makeboxr("$b = \Im(z)$"))
annotate([2*cos(theta/2), 2*sin(theta/2)], [3, 1], 
    makeboxl(r"$\theta = \arg z$"))
annotate([cos(theta), sin(theta)], [-4,4],
         rotatebox(theta/pi*180, r"$r=|z|=\sqrt{a^2+b^2}$"))

closeOutputFile()


