#!/usr/bin/python
# Graph of powers of x, and some multiples of x
from math import *
from grapher import *


setViewBox(-0.2, -0.2, 1.2, 1.2)
openOutputFile("02powerBeatsLinear", 180)

axes()
plotfun((lambda x:x*x))

linewidth(0.5)
plotfun((lambda x:x))

setdash("[2 1] 0")
plotfun((lambda x:x/2))
plotfun((lambda x:x/5))
plotfun((lambda x:x/10))
plotfun((lambda x:x/20))

annotate([1.2, 1.2], [2, 0], makeboxl("$y=x$"))
annotate([1.2, 1.2/2], [2, 0], makeboxl("$y=x/2$"))
annotate([1.2, 1.2/5], [2, 0], makeboxl("$y=x/5$"))
annotate([1.2, 1.2/10], [2, 0], makeboxl("$y=x/10$"))
annotate([1.2, 1.2/20], [2, -3], makeboxl("$y=x/20$"))
annotate([0.9, 0.81], [5,0], makeboxl("$y=x^2$"))

closeOutputFile()


