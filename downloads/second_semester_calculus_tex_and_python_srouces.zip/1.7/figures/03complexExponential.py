from math import *
from grapher import *

setViewBox(-1.5,-1.5, 1.5, 1.5)
openOutputFile("03complexExponential", 120)

OR=[0,0]

axes()
arc(OR, 1, [0, 360])
theta = pi/3
eith = [cos(theta), sin(theta)]
arc(OR, 0.3, [0, theta/pi*180])
line(OR, eith)
roundPoint(eith,0.03)
roundPoint([1, 0],0.03)

annotate([1, 0], [2, 2], makeboxl("$1$"))
annotate(eith, [3, 2], makeboxl(r"$e^{i\theta}= \cos\theta + i \sin\theta$"))
annotate([0.3*cos(theta/2), 0.3*sin(theta/2)], [2, 0], 
         makeboxl(r"$\theta$"))

closeOutputFile()
