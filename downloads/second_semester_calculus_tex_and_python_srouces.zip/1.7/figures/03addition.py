from math import *
from grapher import *

setViewBox(-1, -1, 7, 5)
openOutputFile("03addition", 180)

 
OR=[0,0]
Z=[4,1]
ZRE=[Z[0],0]
W=[2,3]
WRE=[W[0],0]
ZPW = [Z[0]+W[0], Z[1]+W[1]]

arrow(OR, Z, len=7, wid=2, overshoot=0)
arrow(OR, W, len=7, wid=2, overshoot=0)
arrow(OR, ZPW, len=7, wid=2, overshoot=0)
arrow([0, -1], [0, ZPW[1]])
line([-1,0], OR)
arrow([Z[0], 0], [ZPW[0]+0.3, 0])

setdash("[2 5] 0")
#linewidth(2)
polygonA([OR, ZRE, Z])
polygonA([Z, [Z[0]+W[0],Z[1]], ZPW])

setdash("[] 0")
linewidth(0.5)
polygonA([Z, ZPW, W])

annotate([Z[0]/2.0,0], [0, -9], makeboxc("$a$"))
annotate([Z[0],Z[1]/2.0], [-2, -3], makeboxr("$b$"))
annotate([Z[0]+W[0]/2.0,Z[1]], [0, -9], makeboxc("$c$"))
annotate([ZPW[0],Z[1]+W[1]/2.0], [-2, -3], makeboxr("$d$"))

annotate(Z, [-2, 4], makeboxc("$z$"))
annotate(W, [-2, 4], makeboxc("$w$"))
annotate(ZPW, [-2, 2], makeboxc("$z+w$"))


closeOutputFile()
