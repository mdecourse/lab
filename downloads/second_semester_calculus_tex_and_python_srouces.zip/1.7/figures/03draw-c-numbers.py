#!/usr/bin/python

from math import *
from grapher import *


setViewBox(-5, -4, 5, 4)
openOutputFile("03draw-c-numbers", 360)

axes([7,7])
OR=[0,0]
W=[2,1]
line(OR, W)
roundPoint(W)

annotate(W, [-2,0], makeboxr("$w$"))

closeOutputFile()


